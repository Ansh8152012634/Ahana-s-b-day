# Ahana's Birthday 🎂

An interactive, cinematic birthday experience — 9 chapters of memories, puzzles, music, and love.

## Run locally

```bash
npm install
npm run dev
```

Open [http://localhost:5173](http://localhost:5173)

## Deploy to GitHub Pages

### Automatic (recommended)

1. Push this repository to GitHub
2. Go to **Settings → Pages → Source** and set it to **GitHub Actions**
3. Push any commit to `main` — the included workflow deploys automatically

### Manual build

```bash
VITE_BASE_PATH=/your-repo-name/ npm run build
```

Then upload the `dist/` folder contents to any static host.

## Add your photos

In `src/components/chapters/Chapter9Epilogue.tsx`, the 4 Polaroid frames are placeholders.

To add real photos:
1. Put your images in `public/photos/` (e.g. `photo1.jpg`, `photo2.jpg`, etc.)
2. In the `ScrapbookPage` component, replace the placeholder `<div>` inside each Polaroid with:
   ```jsx
   <img src={`${import.meta.env.BASE_URL}photos/photo${idx + 1}.jpg`}
        alt={`Memory ${idx + 1}`}
        className="w-full h-full object-cover" />
   ```

## Add your letter

In `src/components/chapters/Chapter9Epilogue.tsx`, find `LETTER_PARAGRAPHS` near the top and replace the placeholder text with your personal letter. Each string in the array is a paragraph; empty strings `''` create blank lines.

## Stack

- React 18 + TypeScript
- Framer Motion (animations)
- Tailwind CSS v4
- Vite 5
- Web Audio API (procedural music)
